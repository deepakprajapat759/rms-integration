import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-financial-analyst-home',
  templateUrl: './financial-analyst-home.component.html',
  styleUrls: ['./financial-analyst-home.component.css']
})
export class FinancialAnalystHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
