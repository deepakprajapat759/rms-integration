/* export types
named    import  {Links} from './../links.module';
default.  import  Links from './../links.module';
*/

export default class Links{

public static base ='http://localhost:8080/rms/'; 

public static FA_Credit_HOLD = Links.base+'financial-analyst/view-credit-app-form?faid=';

}