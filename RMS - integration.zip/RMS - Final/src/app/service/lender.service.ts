import { Injectable } from '@angular/core';
import { Lender } from '../model/lender';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LenderService {

  private registerUrl:string;
  constructor(private http: HttpClient) {
    this.registerUrl='http://localhost:8080/rms/lender/registerlender';
  }

  public save(lender:Lender){
    return this.http.post<Lender>(this.registerUrl,lender);
  }
}