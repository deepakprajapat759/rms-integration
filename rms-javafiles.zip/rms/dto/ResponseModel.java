package com.casestudy.rms.dto;

import org.springframework.http.HttpStatus;

/**
 * Represents a response consists of
 * @author impetus
 *
 */
public class ResponseModel {
    
    HttpStatus status;
    

}
