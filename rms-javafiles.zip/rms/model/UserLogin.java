package com.casestudy.rms.model;

public class UserLogin {
	 private int userId;
	 private String userName;
	 private String userEmail;
	 private String userRole;
	 private int userAIStatus;
	 private String userPassword;
	 
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public int getUserAIStatus() {
		return userAIStatus;
	}
	public void setUserAIStatus(int userAIStatus) {
		this.userAIStatus = userAIStatus;
	}
	 
	 
}
