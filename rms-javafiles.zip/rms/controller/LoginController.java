package com.casestudy.rms.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.rms.dao.UserDAO;
import com.casestudy.rms.model.LoginUser;
import com.casestudy.rms.model.User;
import com.casestudy.rms.model.UserLogin;

/**
 * 
 *
 */
@RestController
@RequestMapping("/rms/login")
@CrossOrigin(origins = {"http://localhost:4200"})
public class LoginController {
	@Autowired
	private UserDAO userDAO;
	
	/**
	 * 
	 * @return
	 */

//	@RequestMapping(value="/validateLogin", consumes="application/JSON", method=RequestMethod.POST)

	@GetMapping(produces = "application/json")
	@RequestMapping({ "/validateLogin" })
	public UserLogin validateLogin(@RequestParam ("emailId") String emailId ) {
		
		UserLogin user = userDAO.getUserByEmail(emailId);
		return user;
	}

	
	
	/*
    public Principal loginUser(Principal principal) {

        if (userService.getUserByEmail(principal.getName()).getEnabled() == 0) {

               throw new UsernameNotFoundException("Account not activated");

        }

        LOGGER.info(" AccountController :: loginUser :: Inside " + principal);

        User user = userService.getUserByEmail(principal.getName());

        user.setLastLogin(new Date(System.currentTimeMillis()));

        userService.updateUser(user);

        return principal;

 }
    */
	
	
	
}
