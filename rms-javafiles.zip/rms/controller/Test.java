package com.casestudy.rms.controller;

import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test")
@CrossOrigin(origins = {"http://localhost:4200"})
public class Test {

	@GetMapping("/borrower")
	@Secured("ROLE_BORROWER")
	String m1() {
		return "Borrower only.";				
	}
	

	@GetMapping("/lender")
	@Secured("ROLE_LENDER")
	String m2() {
		return "LENDER only.";				
	}
	
	
	@GetMapping("/admin")
	@Secured("ROLE_ADMIN")
	String m3() {
		return "Admin only.";				
	}
	
	@GetMapping("/fa")
	@Secured("ROLE_FINANCIAL_ANALYST")
	String m4() {
		return "FA only.";				
	}
	
}
