package com.casestudy.rms.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

/**
 * 
 * @author neeraj.vyas
 *
 */
@EnableWebSecurity
@Configuration
public class SpringSecurity extends WebSecurityConfigurerAdapter {
		
	
	@Autowired
	private UserDetailsService userDetailsService;
	
    @Bean
	public AuthenticationProvider authProvider() {
		DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
		provider.setUserDetailsService(userDetailsService);
		//provider.setPasswordEncoder(new BCryptPasswordEncoder());
		provider.setPasswordEncoder(NoOpPasswordEncoder.getInstance());

		return provider;
	}
	
	
	/*
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception{
        auth.inMemoryAuthentication()
            .withUser("admin@rms.com").password("{noop}test12345").roles("USER").and()
            .withUser("deepakvyas").password("{noop}test2").roles("ADMIN");
    }
    
    */
    
    
    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception{
        
    	//register - 2 links 
    	
        httpSecurity
                    .authorizeRequests()
                    .antMatchers("/rms/registerborrower","/rms/lender/registerlender")
                    .permitAll()
//                    .antMatchers("/rms/**","/test/**").hasAnyAuthority("ROLE_ADMIN", "ROLE_LENDER", "ROLE_BORROWER", "ROLE_ANALYST")
                    .anyRequest()
                    .fullyAuthenticated()
                    .and().httpBasic();
        
        httpSecurity
			.cors().and().csrf().disable();
	
    	/*
    	 httpSecurity
    	 			.csrf().disable()
    	 			.formLogin()
    	 			.loginPage("/login").permitAll().and().logout().invalidateHttpSession(true)
    	 			.clearAuthentication(true).logoutRequestMatcher(new AntPathRequestMatcher("/logout")) 
         			.logoutSuccessUrl("/logout-success").permitAll();
    	*/
    	
    }
    
}
