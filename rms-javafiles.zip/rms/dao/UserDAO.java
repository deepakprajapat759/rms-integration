package com.casestudy.rms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.User;
import com.casestudy.rms.model.UserLogin;

/**
 * Represents a User DAO.
 * 
 * @author impetus
 *
 */
@Transactional
@Repository
public class UserDAO implements IUserDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void registerBorrower(User user) {
		entityManager.persist(user);
	}

	@Override
	public boolean userExists(User user) {

		String hql = "FROM User WHERE userEmail = ?1";
		int count = entityManager.createQuery(hql).setParameter(1, user.getUserEmail()).getResultList().size();
		return count > 0 ? true : false;
	}

	@Override
	public UserLogin getUserByEmail(String userEmail) {
		String hql = "FROM User WHERE userEmail =?1";
		List<User> userList = (List<User>) entityManager.createQuery(hql).setParameter(1, userEmail).getResultList();
		System.out.print("------------------------ ");
		User user = entityManager.find(User.class, userList.get(0).getUserId());
		System.out.print(" "+user.getUserEmail());
		System.out.print(" "+user.getUserEmail());
		System.out.print(" "+user.getUserEmail());

		UserLogin userLoggedIn = new UserLogin();	
		userLoggedIn.setUserEmail(user.getUserEmail());
		userLoggedIn.setUserId(user.getUserId());
		userLoggedIn.setUserName(user.getUserName());
		userLoggedIn.setUserRole(user.getUserRole());
		userLoggedIn.setUserAIStatus(user.getUserAIStatus());
		userLoggedIn.setUserPassword(user.getUserPassword());
		//Logger
		return userLoggedIn;
	}

}
