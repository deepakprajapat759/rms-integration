package com.casestudy.rms.dao;

import java.util.List;

import com.casestudy.rms.model.Lender;

/**
 * Declare methods for Administrator DAO.
 * @author impetus
 *
 */
public interface IAdminDAO {
    
    /**
     * Get list of Lenders according to status.
     * @param status - User NotApproved/Active/Inactive status
     * @return - List of Lender
     */
    List<Lender> getLenderWithStatus(int status);
}
