package com.casestudy.rms.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MAPPING_CREDITAPP_POLICY")
public class MappingCreditAppPolicy {
  @Id
  @Column(name = "FIELD_ID")
  private int fieldId;

  @Column(name = "APPLICATION_ID")
  private int applicationId;

  @Column(name = "POLICY_ID")
  private int policyId;

  @Column(name = "POLICY_VALUE")
  private String policyValue;

  public int getFieldId() {
    return fieldId;
  }

  public void setFieldId(int fieldId) {
    this.fieldId = fieldId;
  }

  public int getApplicationId() {
    return applicationId;
  }

  public void setApplicationId(int applicationId) {
	this.applicationId = applicationId;
  }

  public int getPolicyId() {
    return policyId;
  }

  public void setPolicyId(int policyId) {
   this.policyId = policyId;
 }

  public String getPolicyValue() {
    return policyValue;
  }

  public void setPolicyValue(String policyValue) {
   this.policyValue = policyValue;
	}

}
