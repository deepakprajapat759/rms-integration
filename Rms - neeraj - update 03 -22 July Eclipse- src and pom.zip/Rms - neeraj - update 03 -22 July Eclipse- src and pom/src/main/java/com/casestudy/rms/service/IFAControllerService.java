/**
 * 
 */
package com.casestudy.rms.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;

import com.casestudy.rms.dto.FinancialAnalystReceivedCreditAppDTO;

/**
 * @author hp
 *
 */
public interface IFAControllerService {

	@Secured("ROLE_FINANCIAL_ANALYST")
	public ResponseEntity<List<FinancialAnalystReceivedCreditAppDTO>> viewCreditApplications(int faid);

}
