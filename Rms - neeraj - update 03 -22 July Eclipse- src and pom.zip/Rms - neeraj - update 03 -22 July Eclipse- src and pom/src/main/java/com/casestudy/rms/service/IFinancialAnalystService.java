package com.casestudy.rms.service;

import java.util.List;

import com.casestudy.rms.dto.FinancialAnalystReceivedCreditAppDTO;

/**
 * Declares set of services for FinancialAnalystService.
 * @author impetus
 *
 */
public interface IFinancialAnalystService {
    
    	List<FinancialAnalystReceivedCreditAppDTO>fetchCreditApp(int faid);
    	
}
