package com.casestudy.rms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.casestudy.rms.dto.FinancialAnalystReceivedCreditAppDTO;

@Service
public class FAControllerService implements IFAControllerService {
	
	@Autowired
	IFinancialAnalystService financialAnalystService;
	
	
	@Override
	public ResponseEntity<List<FinancialAnalystReceivedCreditAppDTO>> viewCreditApplications(int faid) {
		List <FinancialAnalystReceivedCreditAppDTO> responseList = financialAnalystService.fetchCreditApp(faid);
   	 return new ResponseEntity<List<FinancialAnalystReceivedCreditAppDTO>>(responseList, HttpStatus.OK);
	}

}
