package com.casestudy.rms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.rms.service.ITestService;

@RestController
@RequestMapping("/test")
@CrossOrigin(origins = {"http://localhost:4200"})
public class Test {
	
@Autowired
private ITestService testService;

	@GetMapping("/borrower")
	String m1() {
		return testService.m1();				
	}
	

	@GetMapping("/lender")
	String m2() {
		return testService.m2();				
	}
	
	
	@GetMapping("/admin")
	String m3() {
		return testService.m3();				
	}
	
	@GetMapping("/fa")
	String m4() {
		return testService.m4();					
	}
	
}