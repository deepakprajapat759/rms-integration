package com.casestudy.rms.dao;

import com.casestudy.rms.model.FinancialAnalyst;

/** Declares method for Financial Analyst DAO.
 * 
 * @author impetus */
public interface IFinancialAnalystDAO {
    /** Checks Financial Analyst exists or not.
     * 
     * @param financialAnalyst
     *            - Financial Analyst
     * @return Exists or not */
    boolean financialAnalystExist(FinancialAnalyst financialAnalyst);

}
