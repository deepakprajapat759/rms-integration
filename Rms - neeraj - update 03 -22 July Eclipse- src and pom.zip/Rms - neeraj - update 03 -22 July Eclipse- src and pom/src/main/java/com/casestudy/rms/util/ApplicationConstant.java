package com.casestudy.rms.util;

/** Contains Application Constants.
 * 
 * @author impetus */
public final class ApplicationConstant {


    public static final int NOT_APPROVED = 0;
    public static final int ACTIVE = 1;
    public static final int INACTIVE = 2;
    public static final int ADMIN_ID = 0;
    public static final int POLICY_ACTIVE = 1;
    public static final int POLICY_INACTIVE = 0;
    public static final int DEFAULT_POLICY_WEIGHTAGE = 50;
    public static final String DEFAULT_POLICY_THRESHOLD = "YES";
    public static final int MIN_PASSWORD_LENGTH=8;
    public static final int MAX_PASSWORD_LENGTH=20;
    public static final int CREDIT_APP_REJECT = 1;
    public static final int CREDIT_APP_HOLD = 2;
    public static final int CREDIT_APP_APPROVED = 3;
    
    /**
     * Private Constructor.
     */
    private ApplicationConstant() {
        
    }
    

}
