package com.casestudy.rms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.User;

/**
 * Represents a User DAO.
 * 
 * @author impetus
 *
 */
@Transactional
@Repository
public class UserDAO implements IUserDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void registerBorrower(User user) {
		entityManager.persist(user);
	}

	@Override
	public boolean userExists(User user) {

		String hql = "FROM User WHERE userEmail = ?1";
		int count = entityManager.createQuery(hql).setParameter(1, user.getUserEmail()).getResultList().size();
		return count > 0 ? true : false;
	}

	@Override
	public User getUserByEmail(String userEmail) {
		String hql = "FROM User WHERE userEmail =?1";
		@SuppressWarnings("unchecked")
		List<User> userList = (List<User>) entityManager.createQuery(hql).setParameter(1, userEmail).getResultList();
		System.out.print("------------------------ ");
		User user = entityManager.find(User.class, userList.get(0).getUserId());
		System.out.print(" "+user.getUserEmail());
		System.out.print(" "+user.getUserEmail());
		System.out.print(" "+user.getUserEmail());
				
		//Logger
		return user;
	}

	@Override
	public String getUserNamebyUserID(int bid) {
		String hql = "SELECT userName FROM User WHERE userId =?1";
		String userName = (String) entityManager.createQuery(hql).setParameter(1, bid).getResultList().get(0);
		return userName;
	}

	@Override
	public String getUserEmailbyUserID(int bid) {
		String hql = "SELECT userEmail FROM User WHERE userId =?1";
		String userEmail = (String) entityManager.createQuery(hql).setParameter(1, bid).getResultList().get(0);
		return userEmail;
	}

}
