package com.casestudy.rms.model;

/** Represents an Administrator.
 * 
 * @author impetus */
public class Admin {

}
