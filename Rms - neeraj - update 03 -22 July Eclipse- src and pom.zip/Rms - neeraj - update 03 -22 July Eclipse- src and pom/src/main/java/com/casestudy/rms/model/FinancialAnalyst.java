package com.casestudy.rms.model;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

/** Represents a Financial Analyst who extends User properties.
 * 
 * @author impetus */
@Entity
@Table(name = "FINANCIAL_ANALYST")
@PrimaryKeyJoinColumn(name = "FINANCIAL_ANALYST_ID")
public class FinancialAnalyst extends User {


}
