import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-borrower-home',
  templateUrl: './borrower-home.component.html',
  styleUrls: ['./borrower-home.component.css']
})
export class BorrowerHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
