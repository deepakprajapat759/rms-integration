package com.casestudy.rms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.Policy;
import com.casestudy.rms.util.ApplicationConstant;

/** Represents Policy DAO. */
@Transactional
@Repository
public class PolicyDAO implements IPolicyDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public boolean addPolicy(Policy policy) {
        entityManager.persist(policy);

        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Policy> viewPolicy(int lenderId) {
        String hql = "FROM Policy where addedBy = ?1 OR addedBy=?2";
        return (List<Policy>) entityManager.createQuery(hql).setParameter(1, lenderId).setParameter(2, ApplicationConstant.ADMIN_ID).getResultList();
    }

    @Override
    public int getMaxPolicyId() {
        String hql = "SELECT MAX(policyId) FROM Policy";
        return (int) entityManager.createQuery(hql).getResultList().get(0);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Integer> getDefaultPolicyId() {
        String hql = "SELECT policyId FROM Policy WHERE addedBy=?1";
        return (List<Integer>) entityManager.createQuery(hql).setParameter(1, ApplicationConstant.ADMIN_ID).getResultList();
    }

    @Override
    public Policy findPolicy(int policyId) {
        String hql = "FROM Policy where policyId = ?1";
        return (Policy) entityManager.createQuery(hql).setParameter(1, policyId).getResultList().get(0);
    }

}
