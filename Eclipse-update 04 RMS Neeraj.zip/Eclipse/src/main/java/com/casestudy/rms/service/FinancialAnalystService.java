package com.casestudy.rms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.casestudy.rms.dao.ICreditAppDAO;
import com.casestudy.rms.dao.IUserDAO;
import com.casestudy.rms.dto.FinancialAnalystReceivedCreditAppDTO;
import com.casestudy.rms.model.CreditApplication;
import com.casestudy.rms.util.ApplicationConstant;

/**
 * Provides Services to Financial Analyst.
 * @author impetus
 *
 */
@Service
public class FinancialAnalystService implements IFinancialAnalystService {
	
	
	@Autowired
	private ICreditAppDAO creditAppDAO ;
	
	@Autowired
	private IUserDAO userDAO;
	
	
	@Override
	public List<FinancialAnalystReceivedCreditAppDTO> fetchCreditApp(int faid) {
		//fetch CreditApplication Table where faid - logged in  , application status = 2 (Hold)
		
		List<CreditApplication> listCreditApp= creditAppDAO.getCreditApplication(faid, ApplicationConstant.CREDIT_APP_HOLD);
		
		
		
		List<FinancialAnalystReceivedCreditAppDTO> listFAReceivedCreditAppDTO = new ArrayList<>();
		
		for(int i=0; i<listCreditApp.size(); i++  )
		{   FinancialAnalystReceivedCreditAppDTO  temp = new FinancialAnalystReceivedCreditAppDTO();
			temp.setApplicationNumber("APP"+listCreditApp.get(i).getApplicationId());
			temp.setCompanyName(listCreditApp.get(i).getCompanyName());
			temp.setCreditScore(listCreditApp.get(i).getCreditScore());
			temp.setBorrowerName(userDAO.getUserNamebyUserID(listCreditApp.get(i).getBorrowerId()));
			temp.setBorrowerEmail(userDAO.getUserEmailbyUserID(listCreditApp.get(i).getBorrowerId()));
		
			listFAReceivedCreditAppDTO.add(temp);
		}
		
		
		return listFAReceivedCreditAppDTO;
	}


}
