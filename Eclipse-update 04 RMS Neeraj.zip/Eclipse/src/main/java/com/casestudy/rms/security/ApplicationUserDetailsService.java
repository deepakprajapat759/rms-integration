package com.casestudy.rms.security;


import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.casestudy.rms.dao.IUserDAO;

/** This class fetches the user details via email and passes it to MyUserDetails.
 * 
 * @author neeraj.vyas
 *
 */
@Service
public class ApplicationUserDetailsService implements UserDetailsService {

	@Autowired
	private IUserDAO userDAO;

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		// LOGGER.debug(" username for request... " + userName);
		try {

			com.casestudy.rms.model.User activeUserInfo = userDAO.getUserByEmail(userName);
			System.out.println("Inside New UserDetailService");
			System.out.println(activeUserInfo.getUserEmail());
			GrantedAuthority authority = new SimpleGrantedAuthority(activeUserInfo.getUserRole());

			return new MyUserDetails(activeUserInfo.getUserId()+"", activeUserInfo.getUserName(),
					activeUserInfo.getUserEmail(), activeUserInfo.getUserPassword(), Arrays.asList(authority));

		} catch (Exception e) {
			throw new UsernameNotFoundException("Invalid Credentials.");
		}
	}
}
