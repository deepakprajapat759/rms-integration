package com.casestudy.rms.dao;

import java.util.List;

import com.casestudy.rms.model.CreditApplication;

public interface ICreditAppDAO {
  void submitCreditAppForm(CreditApplication creditApp);
  
  /** Fetch List of credit application.
   * 
   * @param faid - current financial analyst logged in.
   * @param status - hold,approve,reject.
   * @return
   */
  List<CreditApplication> getCreditApplication(int faid, int status);
  
}
