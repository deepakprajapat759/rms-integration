package com.casestudy.rms.model;

/** class used to validate login.
 * 
 * @author neeraj.vyas
 *
 */
public class LoginUser {
	private String status;
	private String userId;
	private String userRole;
	private String userEmail;

	
	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	/**
	 * 
	 * @param status
	 */
	public LoginUser(String status) {
		this.status=status;
	}	
	
	/**
	 * 
	 * @return
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * 
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}
