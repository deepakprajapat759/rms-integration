package com.casestudy.rms.service;

import org.springframework.security.access.annotation.Secured;

/**
 * 
 * @author neeraj.vyas
 *
 */
public interface ITestService {
	
	@Secured("ROLE_BORROWER")
	public String m1();
	
	@Secured("ROLE_LENDER")
	public String m2();
	
	
	@Secured("ROLE_ADMIN")
	public String m3();
	
	@Secured("ROLE_FINANCIAL_ANALYST")
	public String m4();
	
}
