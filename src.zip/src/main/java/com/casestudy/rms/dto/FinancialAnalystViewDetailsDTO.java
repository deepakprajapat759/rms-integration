package com.casestudy.rms.dto;

import java.util.List;

public class FinancialAnalystViewDetailsDTO {

	
		private String applicationNumber;
		private String applicationStatus;
		
		private String LenderID;
		private String LenderEmail;
		
		private String BorrowerID;
		private String BorrowerEmail;
		
		
		private List<String> policyNamebyLender;
		private List<String> policyValuebyBorrower;
		private List<String> policyWeightagebyLender;
		private List<String> policyThresholdbyLender;
		
		public String getApplicationNumber() {
			return applicationNumber;
		}
		public void setApplicationNumber(String applicationNumber) {
			this.applicationNumber = applicationNumber;
		}
		public String getApplicationStatus() {
			return applicationStatus;
		}
		public void setApplicationStatus(String applicationStatus) {
			this.applicationStatus = applicationStatus;
		}
		public String getLenderID() {
			return LenderID;
		}
		public void setLenderID(String lenderID) {
			LenderID = lenderID;
		}
		public String getLenderEmail() {
			return LenderEmail;
		}
		public void setLenderEmail(String lenderEmail) {
			LenderEmail = lenderEmail;
		}
		public String getBorrowerID() {
			return BorrowerID;
		}
		public void setBorrowerID(String borrowerID) {
			BorrowerID = borrowerID;
		}
		public String getBorrowerEmail() {
			return BorrowerEmail;
		}
		public void setBorrowerEmail(String borrowerEmail) {
			BorrowerEmail = borrowerEmail;
		}
		public List<String> getPolicyNamebyLender() {
			return policyNamebyLender;
		}
		public void setPolicyNamebyLender(List<String> policyNamebyLender) {
			this.policyNamebyLender = policyNamebyLender;
		}
		public List<String> getPolicyValuebyBorrower() {
			return policyValuebyBorrower;
		}
		public void setPolicyValuebyBorrower(List<String> policyValuebyBorrower) {
			this.policyValuebyBorrower = policyValuebyBorrower;
		}
		public List<String> getPolicyWeightagebyLender() {
			return policyWeightagebyLender;
		}
		public void setPolicyWeightagebyLender(List<String> policyWeightagebyLender) {
			this.policyWeightagebyLender = policyWeightagebyLender;
		}
		public List<String> getPolicyThresholdbyLender() {
			return policyThresholdbyLender;
		}
		public void setPolicyThresholdbyLender(List<String> policyThresholdbyLender) {
			this.policyThresholdbyLender = policyThresholdbyLender;
		}
		
		
		
		
}
