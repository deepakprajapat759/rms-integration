package com.casestudy.rms.dto;
import java.util.List;
public class ResponseObjectDTO extends ResponseModel{
    
    List<Object> data;
    public List<Object> getData() {
        return data;
    }
    public void setData(List<Object> data) {
        this.data = data;
    }
    @Override
    public String toString() {
        return "ResponseObjectDTO [data=" + data + "]";
    }
    
}