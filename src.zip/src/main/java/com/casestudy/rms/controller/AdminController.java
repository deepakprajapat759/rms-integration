package com.casestudy.rms.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.rms.model.Lender;
import com.casestudy.rms.service.IAdminService;

/** Represents Administrator Controller. */
@RestController
@RequestMapping("/rms")
@CrossOrigin(origins = { "http://localhost:4200" })
public class AdminController {

    public static final Logger LOGGER = Logger.getLogger(AdminController.class);

    @Autowired
    private IAdminService adminService;

    /** Gets Non-approved Lenders.
     * 
     * @return List of Non-approved Lenders */
    @GetMapping("viewLenders/PendingLenders")
    public ResponseEntity<List<Lender>> getPendingLenders() {
        LOGGER.debug("AdminController :: getPendingLenders ");
        List<Lender> lst = adminService.getPendingLenders();
        return new ResponseEntity<>(lst, HttpStatus.OK);
    }

    /** Gets Active Lenders.
     * 
     * @return List of Active Lenders. */
    @GetMapping("viewLenders/ActiveLenders")
    public ResponseEntity<List<Lender>> getActiveLenders() {
        LOGGER.debug("AdminController :: getActiveLenders ");
        List<Lender> lst = adminService.getActiveLenders();
        return new ResponseEntity<>(lst, HttpStatus.OK);
    }

    /** Gets Inactive Lenders.
     * 
     * @return List of Inactive Lenders. */
    @GetMapping("viewLenders/InactiveLenders")
    public ResponseEntity<List<Lender>> getInactiveLenders() {
        LOGGER.debug("AdminController :: getInactiveLenders ");
        List<Lender> lst = adminService.getInactiveLenders();
        return new ResponseEntity<>(lst, HttpStatus.OK);
    }

}