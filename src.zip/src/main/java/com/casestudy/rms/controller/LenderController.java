package com.casestudy.rms.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.rms.dto.PolicyResponse;
import com.casestudy.rms.dto.ResponseModel;
import com.casestudy.rms.model.FinancialAnalyst;
import com.casestudy.rms.model.Lender;
import com.casestudy.rms.service.ILenderService;

/**
 * Represents Lender Controller.
 * 
 * @author impetus
 *
 */
@RestController
@RequestMapping("/rms/lender")
@CrossOrigin(origins = { "http://localhost:4200" })
public class LenderController {

	public static final Logger LOGGER = Logger.getLogger(LenderController.class);

	@Autowired
	private ILenderService lenderService;

	/**
	 * Register a Lender.
	 * 
	 * @param lender - Lender
	 * @return Status
	 */
	@PostMapping(value = "/registerlender", consumes = "application/JSON")
	public ResponseEntity<ResponseModel> registerLender(@RequestBody Lender lender) {
		LOGGER.debug("LenderController :: registerLender ");
		ResponseModel response = lenderService.registerLender(lender);
		return new ResponseEntity<>(response,HttpStatus.CREATED);

	}

	/**
	 * Add Financial Analysts.
	 * 
	 * @param financialAnalyst - Financial Analyst
	 * @param id               - Lender ID
	 * @return Status
	 */
	@PostMapping(value = "/addFinancialAnalyst", consumes = "application/JSON")
	public ResponseEntity<ResponseModel> addFinancialAnalyst(@RequestBody FinancialAnalyst financialAnalyst,
			@RequestParam("id") int id) {
		LOGGER.debug("LenderController :: addFinancialAnalyst ");
		Lender lender = lenderService.getLender(id);
		ResponseModel response = lenderService.addFinancialAnalyst(financialAnalyst, lender);

		return new ResponseEntity<>(response,HttpStatus.CREATED);

	}
	
	 /** Add new policy.
     * 
     * @param policyResponse
     *            - DTO contains policy detail
     * @param id
     *            - Lender ID
     * @return Status */
    @PostMapping(value = "/addPolicy", consumes = "application/JSON")
    public ResponseEntity<ResponseModel> addPolicy(@RequestBody PolicyResponse policyResponse, @RequestParam("id") int id) {
        LOGGER.debug("LenderController :: addPolicy ");
        Lender lender = lenderService.getLender(id);
        ResponseModel response = lenderService.addPolicy(policyResponse, lender);
        return new ResponseEntity<>(response,HttpStatus.CREATED);
       
         
    }

    /** View default policies detail and policies detail corresponding lender.
     * 
     * @param id
     *            - Lender ID
     * @return Status */
    @GetMapping("/viewPolicy")
    public ResponseEntity<List<PolicyResponse>> viewPolicy(@RequestParam("id") int id) {
        LOGGER.debug("LenderController :: viewPolicy ");
        List<PolicyResponse> policy = lenderService.viewPolicy(id);
        return new ResponseEntity<>(policy, HttpStatus.OK);
    }

    /** Update policies detail corresponding to lender.
     * 
     * @param policyResponses
     *            - Array of different policies detail
     * @param id
     *            - Lender ID
     * @return Status */
    @PostMapping(value = "/updatePolicyDetail", consumes = "application/JSON")
    public ResponseEntity<ResponseModel> updatePolicyDetails(@RequestBody PolicyResponse[] policyResponses, @RequestParam("id") int id) {
        LOGGER.debug("LenderController :: updatePolicyDetails ");
        Lender lender = lenderService.getLender(id);
        ResponseModel response = lenderService.updatePolicyDetail(policyResponses, lender);
      
        return new ResponseEntity<>(response,HttpStatus.OK);
      
    }
    
    /**
     * View Financial Analyst.
     * @param id - lender id
     * @return List of financial analyst
     */
    @GetMapping("/viewFinancialAnalyst")
    public ResponseEntity<List<FinancialAnalyst>> viewFinancialAnalyst(@RequestParam("id") int id) {
        LOGGER.debug("LenderController :: viewFinancialAnalyst ");
        List<FinancialAnalyst> financialAnalyst = lenderService.viewFinancialAnalyst(id);
        return new ResponseEntity<>(financialAnalyst, HttpStatus.OK);
    }

}


