package com.casestudy.rms.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.rms.dto.ResponseModel;
import com.casestudy.rms.model.User;
import com.casestudy.rms.service.IUserService;

/** Represents an User Controller. */
@RestController
@RequestMapping("/rms")
@CrossOrigin(origins = { "http://localhost:4200" })
public class UserController {
    
    public static final Logger LOGGER = Logger.getLogger(UserController.class);

    @Autowired
    private IUserService userService;

    /** Register a Borrower.
     * 
     * @param user
     *            - Borrower
     * @return Status */
    @PostMapping(value = "/registerborrower", consumes = "application/JSON")
    public ResponseEntity<ResponseModel> registerBorrower(@RequestBody User user) {
        LOGGER.debug("UserController :: registerBorrower ");
        ResponseModel response = userService.registerBorrower(user);
        return new ResponseEntity<>(response,HttpStatus.CREATED);
    }

}