package com.casestudy.rms.model;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;



/** Represents a Financial Analyst who extends User properties. */
@Entity
@Table(name = "FINANCIAL_ANALYST")
@PrimaryKeyJoinColumn(name = "FINANCIAL_ANALYST_ID")
public class FinancialAnalyst extends User {
    
   
	@JsonBackReference
    @ManyToOne
    private Lender lender;

    /**
     * Gets lender corresponding to financial analyst.
     * @return lender
     */
    public Lender getLender() {
        return lender;
    }

    /**
     * Sets lender corresponding to financial analyst.
     * @param lender - lender
     */
    public void setLender(Lender lender) {
        this.lender = lender;
    }
    
    
   

}