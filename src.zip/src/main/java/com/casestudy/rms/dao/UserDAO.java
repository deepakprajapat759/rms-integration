package com.casestudy.rms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.User;

/** Represents a User DAO. */
@Repository
public class UserDAO implements IUserDAO {

    public static final Logger LOGGER = Logger.getLogger(UserDAO.class);

    @PersistenceContext
    private EntityManager entityManager;

    @Transactional
    @Override
    public void registerBorrower(User user) {
        LOGGER.debug("UserDAO :: registerBorrower ");
        entityManager.persist(user);
    }
    
    @Override
    public boolean userExists(User user) {
        LOGGER.debug("UserDAO :: userExists ");
        String hql = "FROM User WHERE userEmail = ?1";
        int count = entityManager.createQuery(hql).setParameter(1, user.getUserEmail()).getResultList().size();
        return count > 0;
    }

	@Override
	public User getUserByEmail(String userEmail) {
		LOGGER.debug("UserDAO :: getUserByEmail ");
	    String hql = "FROM User WHERE userEmail =?1";
		List<User> userList = (List<User>) entityManager.createQuery(hql).setParameter(1, userEmail).getResultList();
		User user = entityManager.find(User.class, userList.get(0).getUserId());
		//Logger
		return user;
	}

	@Override
	public String getUserNamebyUserID(int bid) {
		LOGGER.debug("UserDAO :: getUserNamebyUserID ");
		String hql = "SELECT userName FROM User WHERE userId =?1";
		String userName = (String) entityManager.createQuery(hql).setParameter(1, bid).getResultList().get(0);
		return userName;
	}

	@Override
	public String getUserEmailbyUserID(int bid) {
		LOGGER.debug("UserDAO :: getUserEmailbyUserID ");
		String hql = "SELECT userEmail FROM User WHERE userId =?1";
		String userEmail = (String) entityManager.createQuery(hql).setParameter(1, bid).getResultList().get(0);
		return userEmail;
	}

}
