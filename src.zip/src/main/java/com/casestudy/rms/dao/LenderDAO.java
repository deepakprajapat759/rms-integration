package com.casestudy.rms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.FinancialAnalyst;
import com.casestudy.rms.model.Lender;

/** Represents Lender DAO. */

@Repository
public class LenderDAO implements ILenderDAO {

    public static final Logger LOGGER = Logger.getLogger(LenderDAO.class);

    @PersistenceContext
    private EntityManager entityManager;

    @Transactional
    @Override
    public void registerLender(Lender lender) {
        LOGGER.debug("LenderDAO :: registerLender ");
        entityManager.persist(lender);

    }

    @Override
    public boolean lenderExists(Lender lender) {
        LOGGER.debug("LenderDAO :: lenderExists ");
        String hql = "FROM User WHERE userEmail = ?1";
        int count = entityManager.createQuery(hql).setParameter(1, lender.getUserEmail()).getResultList().size();
        return count > 0;
    }

    @Transactional
    @Override
    public void addFinancialAnalyst(FinancialAnalyst financialAnalyst) {
        LOGGER.debug("LenderDAO :: addFinancialAnalyst ");
        entityManager.persist(financialAnalyst);

    }

    @Override
    public Lender getLender(int lenderId) {
        LOGGER.debug("LenderDAO :: getLender ");
        return entityManager.find(Lender.class, lenderId);
    }

    @Override
    public int getMaxLenderId() {
        LOGGER.debug("LenderDAO :: getMaxLenderId ");
        String hql = "SELECT MAX(userId) FROM Lender";
        return (int) entityManager.createQuery(hql).getResultList().get(0);
    }

}