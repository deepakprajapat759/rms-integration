package com.casestudy.rms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import com.casestudy.rms.model.Lender;

/** Represents Administrator DAO. */

@Repository
public class AdminDAO implements IAdminDAO {

    public static final Logger LOGGER = Logger.getLogger(AdminDAO.class);

    @PersistenceContext
    private EntityManager entityManager;

    @SuppressWarnings("unchecked")
    @Override
    public List<Lender> getLenderWithStatus(int status) {
        LOGGER.debug("AdminDAO :: getLenderWithStatus  ");

        String hql = "FROM Lender where userAIStatus=?1";
        return (List<Lender>) entityManager.createQuery(hql).setParameter(1, status).getResultList();
    }

}