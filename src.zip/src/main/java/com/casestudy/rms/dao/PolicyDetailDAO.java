package com.casestudy.rms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.Lender;
import com.casestudy.rms.model.PolicyDetail;

/** Represents Policy Detail DAO. */

@Repository
public class PolicyDetailDAO implements IPolicyDetailDAO {

    public static final Logger LOGGER = Logger.getLogger(PolicyDetailDAO.class);

    @PersistenceContext
    private EntityManager entityManager;

    @Transactional
    @Override
    public boolean addPolicyDetail(PolicyDetail policyDetail) {
        LOGGER.debug("PolicyDetailDAO :: addPolicyDetail ");
        entityManager.persist(policyDetail);
        return false;
    }

    @Override
    public boolean policyDetailExist(PolicyDetail policyDetail) {
        LOGGER.debug("PolicyDetailDAO :: policyDetailExist ");
        String hql = "FROM PolicyDetail where policyId =?1 AND lenderId = ?2";
        int count = entityManager.createQuery(hql).setParameter(1, policyDetail.getPolicyId()).setParameter(2, policyDetail.getLenderId())
                .getResultList().size();
        return count > 0;
    }

    @Transactional
    @Override
    public boolean updatePolicyDetail(PolicyDetail policyDetail) {
        LOGGER.debug("PolicyDetailDAO :: updatePolicyDetail ");
        entityManager.flush();

        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<PolicyDetail> viewpolicyDetail(int lenderId) {
        LOGGER.debug("PolicyDetailDAO :: viewpolicyDetail ");
        String hql = "FROM PolicyDetail where lenderId=?1";
        return (List<PolicyDetail>) entityManager.createQuery(hql).setParameter(1, lenderId).getResultList();

    }

    @Override
    public PolicyDetail findPolicyDetail(int policyId, Lender lender) {
        LOGGER.debug("PolicyDetailDAO :: findPolicyDetail ");
        String hql = "FROM PolicyDetail where lenderId=?1 and policyId=?2";
        return (PolicyDetail) entityManager.createQuery(hql).setParameter(1, lender.getUserId()).setParameter(2, policyId).getResultList().get(0);
    }

}
