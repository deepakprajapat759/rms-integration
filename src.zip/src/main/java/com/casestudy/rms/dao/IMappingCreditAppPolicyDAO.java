package com.casestudy.rms.dao;

import com.casestudy.rms.model.MappingCreditAppPolicy;

public interface IMappingCreditAppPolicyDAO {

  void submitFormValue(MappingCreditAppPolicy mappingCreditAppPolicy); 
}
