package com.casestudy.rms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.CreditApplication;


@Transactional
@Repository
public class CreditAppDAO implements ICreditAppDAO{

  @PersistenceContext
  private EntityManager entityManager;
  
  @Override
  public void submitCreditAppForm(CreditApplication creditApp) {
    entityManager.persist(creditApp);
  }

@Override
public List<CreditApplication> getCreditApplication(int faid, int status) {
	String hql = "FROM CreditApplication WHERE financialAnalystId =?1 and applicationStatus=?2 ";
	//financialAnalystId
	//applicationStatus
	
	List<CreditApplication> creditAppList = (List<CreditApplication>) entityManager.createQuery(hql).setParameter(1, faid).setParameter(2, status).getResultList();
	
	return creditAppList;
}


}
