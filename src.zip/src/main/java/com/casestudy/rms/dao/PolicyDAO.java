package com.casestudy.rms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.casestudy.rms.model.Policy;
import com.casestudy.rms.util.ApplicationConstant;

/** Represents Policy DAO. */

@Repository
public class PolicyDAO implements IPolicyDAO {

    public static final Logger LOGGER = Logger.getLogger(PolicyDAO.class);

    @PersistenceContext
    private EntityManager entityManager;

    @Transactional
    @Override
    public boolean addPolicy(Policy policy) {
        LOGGER.debug("PolicyDAO :: addPolicy ");
        entityManager.persist(policy);

        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Policy> viewPolicy(int lenderId) {
        LOGGER.debug("PolicyDAO :: viewPolicy ");
        String hql = "FROM Policy where addedBy = ?1 OR addedBy=?2";
        return (List<Policy>) entityManager.createQuery(hql).setParameter(1, lenderId).setParameter(2, ApplicationConstant.ADMIN_ID).getResultList();
    }

    @Override
    public int getMaxPolicyId() {
        LOGGER.debug("PolicyDAO :: getMaxPolicyId ");
        String hql = "SELECT MAX(policyId) FROM Policy";
        return (int) entityManager.createQuery(hql).getResultList().get(0);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Integer> getDefaultPolicyId() {
        LOGGER.debug("PolicyDAO :: getDefaultPolicyId ");
        String hql = "SELECT policyId FROM Policy WHERE addedBy=?1";
        return (List<Integer>) entityManager.createQuery(hql).setParameter(1, ApplicationConstant.ADMIN_ID).getResultList();
    }

    @Override
    public Policy findPolicy(int policyId) {
        LOGGER.debug("PolicyDAO :: findPolicy ");
        String hql = "FROM Policy where policyId = ?1";
        return (Policy) entityManager.createQuery(hql).setParameter(1, policyId).getResultList().get(0);
    }

    @Override
    public boolean policyNameExist(int lenderId, String policyName) {
        LOGGER.debug("PolicyDAO :: policyNameExist ");
        String hql = "FROM Policy where addedBy=?1 and policyName=?2";
        int count = entityManager.createQuery(hql).setParameter(1, lenderId).setParameter(2, policyName.toUpperCase()).getResultList().size();
        return count > 0;
    }

}