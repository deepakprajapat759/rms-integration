package com.casestudy.rms.dao;

import com.casestudy.rms.model.CreditApplication;
import com.casestudy.rms.model.MappingCreditAppPolicy;

public class MappingCreditAppPolicyDAO  implements IMappingCreditAppPolicyDAO{

  public void submitFormValue(CreditApplication creditApp) {
    
  }

  @Override
  public void submitFormValue(MappingCreditAppPolicy mappingCreditAppPolicy) {
    
  }

}
