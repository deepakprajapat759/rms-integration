package com.casestudy.rms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;


import com.casestudy.rms.model.FinancialAnalyst;

/** Represents Financial Analyst DAO. */

@Repository
public class FinancialAnalystDAO implements IFinancialAnalystDAO {

    public static final Logger LOGGER = Logger.getLogger(FinancialAnalystDAO.class);

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public boolean financialAnalystExist(FinancialAnalyst financialAnalyst) {

        LOGGER.debug("FinancialAnalystDAO :: financialAnalystExist");
        String hql = "FROM User WHERE userEmail = ?1";
        int count = entityManager.createQuery(hql).setParameter(1, financialAnalyst.getUserEmail()).getResultList().size();
        return count > 0;
    }

    @Override
    public List viewFinancialAnalyst() {
        String hql = "FROM FinancialAnalyst";
        return entityManager.createQuery(hql).getResultList();
    }
    
    

}