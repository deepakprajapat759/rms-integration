package com.casestudy.rms.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.casestudy.rms.dao.IFinancialAnalystDAO;
import com.casestudy.rms.dao.ILenderDAO;
import com.casestudy.rms.dao.IPolicyDAO;
import com.casestudy.rms.dao.IPolicyDetailDAO;
import com.casestudy.rms.dto.PolicyResponse;
import com.casestudy.rms.dto.ResponseModel;
import com.casestudy.rms.exception.PolicyExistsException;
import com.casestudy.rms.exception.PolicyInputInvalidException;
import com.casestudy.rms.exception.UserExistsException;
import com.casestudy.rms.exception.UserInputInvalidException;
import com.casestudy.rms.model.FinancialAnalyst;
import com.casestudy.rms.model.Lender;
import com.casestudy.rms.model.Policy;
import com.casestudy.rms.model.PolicyDetail;
import com.casestudy.rms.util.ApplicationConstant;

/** Provides services to Lender. */
@Service
public class LenderService implements ILenderService {

	public static final Logger LOGGER = Logger.getLogger(LenderService.class);

	@Autowired
	private ILenderDAO lenderDAO;

	@Autowired
	private IFinancialAnalystDAO financialAnalystDAO;

	@Autowired
	private IPolicyDAO policyDAO;

	@Autowired
	private IPolicyDetailDAO policyDetailDAO;

	@Override
	public ResponseModel registerLender(Lender lender) {
		LOGGER.debug("LenderService :: registerLender");
		if (lender.getUserName() == null || lender.getUserName().isEmpty()) {
			LOGGER.error("LenderService :: registerLender :: Name cannot be Empty");
			throw new UserInputInvalidException("Name cannot be empty");
		} else if (lender.getUserEmail() == null || lender.getUserEmail().isEmpty()
				|| lender.getUserEmail().matches("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\\\.[A-Z]{2,6}$")) {
			LOGGER.error("LenderService :: registerLender :: Email is not valid");
			throw new UserInputInvalidException("Email cannot be empty or Email is invalid");
		} else if (lender.getUserPassword().length() < ApplicationConstant.MIN_PASSWORD_LENGTH
				|| lender.getUserPassword().length() > ApplicationConstant.MAX_PASSWORD_LENGTH
				|| lender.getUserPassword() == null || lender.getUserPassword().isEmpty()) {
			LOGGER.error("LenderService :: registerLender :: Password is not valid");
			throw new UserInputInvalidException("Password length must be atleast 8");
		} else if (lenderDAO.lenderExists(lender)) {
			LOGGER.error("LenderService :: registerLender :: User already exits");
			throw new UserExistsException("User already exists");
		} else {
			BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();
			lender.setUserPassword(bcrypt.encode(lender.getUserPassword()));
			lender.setUserAIStatus(ApplicationConstant.ACTIVE);
			lender.setUserRole("ROLE_LENDER");
			lender.setCreationDate(LocalDateTime.now());
			lender.setModificationDate(LocalDateTime.now());
			lenderDAO.registerLender(lender);

			List<Integer> defaultPolicyIdLst = policyDAO.getDefaultPolicyId();
			for (int i = 0; i < defaultPolicyIdLst.size(); i++) {
				PolicyDetail policyDetail = new PolicyDetail();
				policyDetail.setPolicyId(defaultPolicyIdLst.get(i));
				policyDetail.setPolicyStatus(ApplicationConstant.POLICY_INACTIVE);
				policyDetail.setPolicyWeightage(ApplicationConstant.DEFAULT_POLICY_WEIGHTAGE);
				policyDetail.setThreshold(ApplicationConstant.DEFAULT_POLICY_THRESHOLD);
				policyDetail.setLenderId(lenderDAO.getMaxLenderId());
				policyDetailDAO.addPolicyDetail(policyDetail);
			}
			
			  
            ResponseModel response = new ResponseModel();
            response.setMessage("Lender registered successfully");
            response.setStatus(HttpStatus.CREATED.value());
            response.setTimestamp(LocalDateTime.now());
            return response;


		}

	}

	@Override
	public ResponseModel addFinancialAnalyst(FinancialAnalyst financialAnalyst, Lender lender) {
		LOGGER.debug("LenderService :: addFinancialAnalyst");

		if (financialAnalyst.getUserName() == null || financialAnalyst.getUserName().isEmpty()) {
			LOGGER.error("LenderService :: addFinancialAnalyst :: Name cannot be Empty");
			throw new UserInputInvalidException("Name cannot be empty");
		} else if (financialAnalyst.getUserEmail() == null || financialAnalyst.getUserEmail().isEmpty()
				|| financialAnalyst.getUserEmail().matches("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\\\.[A-Z]{2,6}$")) {
			LOGGER.error("LenderService :: addFinancialAnalyst :: Email is not valid");
			throw new UserInputInvalidException("Email cannot be empty or Email is invalid");
		} else if (financialAnalyst.getUserPassword().length() < ApplicationConstant.MIN_PASSWORD_LENGTH
				|| financialAnalyst.getUserPassword().length() > ApplicationConstant.MAX_PASSWORD_LENGTH
				|| financialAnalyst.getUserPassword() == null || financialAnalyst.getUserPassword().isEmpty()) {
			LOGGER.error("LenderService :: addFinancialAnalyst :: Password is not valid");
			throw new UserInputInvalidException("Password length must be atleast 8");
		} else if (financialAnalystDAO.financialAnalystExist(financialAnalyst)) {
			LOGGER.error("LenderService :: addFinancialAnalyst :: User already exits");
			throw new UserExistsException("User already exists");
		} else {
			BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();
			financialAnalyst.setUserPassword(bcrypt.encode(financialAnalyst.getUserPassword()));
			List<FinancialAnalyst> financialAnalystLst = lender.getFinancialAnalysts();
			financialAnalystLst.add(financialAnalyst);
			lender.setFinancialAnalysts(financialAnalystLst);

			financialAnalyst.setUserAIStatus(ApplicationConstant.ACTIVE);
			financialAnalyst.setUserRole("ROLE_FINANCIALANALYST");
			financialAnalyst.setCreationDate(LocalDateTime.now());
			financialAnalyst.setModificationDate(LocalDateTime.now());
			financialAnalyst.setLender(lender);
			lenderDAO.addFinancialAnalyst(financialAnalyst);
			
			 ResponseModel response = new ResponseModel();
	            response.setMessage("Financial Analyst added successfully");
	            response.setStatus(HttpStatus.CREATED.value());
	            response.setTimestamp(LocalDateTime.now());
	            return response;

		}
	}

	@Override
	public Lender getLender(int lenderId) {
		LOGGER.debug("LenderService :: getLender");
		return lenderDAO.getLender(lenderId);
	}

	@Override
	public ResponseModel addPolicy(PolicyResponse policyResponse, Lender lender) {
		LOGGER.debug("LenderService :: addPolicy");
		if (policyResponse.getPolicyName() == null || policyResponse.getPolicyName().isEmpty()) {
			LOGGER.error("LenderService :: addPolicy :: Policy Name cannot be Empty");
			throw new PolicyInputInvalidException("Policy Name cannot be empty");
		} else if (policyResponse.getThreshold() == null || policyResponse.getPolicyName().isEmpty()) {
			LOGGER.error("LenderService :: addPolicy :: Policy Threshold value cannot be Empty");
			throw new PolicyInputInvalidException("Policy Threshold value cannot be empty");
		} else if (policyDAO.policyNameExist(lender.getUserId(), policyResponse.getPolicyName())) {
			LOGGER.error("LenderService :: addPolicy :: Policy Already Exists");
			throw new PolicyExistsException("Policy Already Exists");
		} else {
			Policy policy = new Policy();
			policy.setPolicyName(policyResponse.getPolicyName().toUpperCase());
			policy.setAddedBy(lender.getUserId());
			policy.setCreationDate(LocalDateTime.now());
			policy.setModificationDate(LocalDateTime.now());
			policyDAO.addPolicy(policy);

			PolicyDetail policyDetail = new PolicyDetail();
			policyDetail.setLenderId(lender.getUserId());
			policyDetail.setPolicyWeightage(policyResponse.getPolicyWeightage());
			policyDetail.setThreshold(policyResponse.getThreshold());
			policyDetail.setPolicyStatus(ApplicationConstant.POLICY_ACTIVE);
			policyDetail.setPolicyId(policyDAO.getMaxPolicyId());
			policyDetailDAO.addPolicyDetail(policyDetail);
			
			 ResponseModel response = new ResponseModel();
	            response.setMessage("Policy added successfully");
	            response.setStatus(HttpStatus.CREATED.value());
	            response.setTimestamp(LocalDateTime.now());
	            return response;

		}
	}

	@Override
	public ResponseModel updatePolicyDetail(PolicyResponse[] policyResponses, Lender lender) {
		LOGGER.debug("LenderService :: updatePolicyDetail");
		for (int i = 0; i < policyResponses.length; i++) {

			PolicyDetail policyDetail = policyDetailDAO.findPolicyDetail(policyResponses[i].getPolicyId(), lender);
			policyDetail.setPolicyStatus(policyResponses[i].getPolicyStatus());
			policyDetail.setPolicyWeightage(policyResponses[i].getPolicyWeightage());
			policyDetail.setThreshold(policyResponses[i].getThreshold());
			policyDetailDAO.updatePolicyDetail(policyDetail);
			
		}

		ResponseModel response = new ResponseModel();
        response.setMessage("Policy updated successfully");
        response.setStatus(HttpStatus.OK.value());
        response.setTimestamp(LocalDateTime.now());
        return response;
	}

	@Override
	public List<PolicyResponse> viewPolicy(int lenderId) {
		LOGGER.debug("LenderService :: viewPolicy");
		List<Policy> policy = policyDAO.viewPolicy(lenderId);
		List<PolicyDetail> policydetail = policyDetailDAO.viewpolicyDetail(lenderId);
		List<PolicyResponse> policyResponseLst = new ArrayList<>();

		for (int i = 0; i < policy.size(); i++) {

			for (int j = 0; j < policydetail.size(); j++) {

				if ((policy.get(i).getPolicyId() == policydetail.get(j).getPolicyId())) {

					PolicyResponse policyResponse = new PolicyResponse();
					policyResponse.setPolicyId(policy.get(i).getPolicyId());
					policyResponse.setThreshold(policydetail.get(j).getThreshold());
					policyResponse.setPolicyName(policy.get(i).getPolicyName());
					policyResponse.setPolicyWeightage(policydetail.get(j).getPolicyWeightage());
					policyResponse.setPolicyStatus(policydetail.get(j).getPolicyStatus());
					policyResponseLst.add(policyResponse);

				}
			}

		}

		return policyResponseLst;
	}

	@Override
	public List<FinancialAnalyst> viewFinancialAnalyst(int lenderId) {

		LOGGER.debug("LenderService :: viewFinancialAnalyst");

		List<FinancialAnalyst> financialAnalysts = financialAnalystDAO.viewFinancialAnalyst();
		List<FinancialAnalyst> lenderFinancialAnalyst = new ArrayList<>();
		for (int i = 0; i < financialAnalysts.size(); i++) {
			if (financialAnalysts.get(i).getLender().getUserId() == lenderId) {
				lenderFinancialAnalyst.add(financialAnalysts.get(i));
			}

		}
		return lenderFinancialAnalyst;
	}

}