package com.casestudy.rms.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.casestudy.rms.util.ApplicationConstant;

import com.casestudy.rms.dao.IAdminDAO;
import com.casestudy.rms.model.Lender;

/** Provides services to Administrator. */
@Service
public class AdminService implements IAdminService {

    public static final Logger LOGGER = Logger.getLogger(AdminService.class);

    @Autowired
    private IAdminDAO adminDAO;

    @Override
    public List<Lender> getPendingLenders() {
        LOGGER.debug("AdminService :: getPendingLenders ");
        return adminDAO.getLenderWithStatus(ApplicationConstant.NOT_APPROVED);
    }

    @Override
    public List<Lender> getActiveLenders() {
        LOGGER.debug("AdminService :: getActiveLenders ");
        return adminDAO.getLenderWithStatus(ApplicationConstant.ACTIVE);
    }

    @Override
    public List<Lender> getInactiveLenders() {
        LOGGER.debug("AdminService :: getInactiveLenders ");
        return adminDAO.getLenderWithStatus(ApplicationConstant.INACTIVE);
    }

}