package com.casestudy.rms.service;

import java.time.LocalDateTime;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.casestudy.rms.dao.IUserDAO;
import com.casestudy.rms.dto.ResponseModel;
import com.casestudy.rms.exception.UserExistsException;
import com.casestudy.rms.exception.UserInputInvalidException;
import com.casestudy.rms.model.User;
import com.casestudy.rms.util.ApplicationConstant;

/** Provides services to User. */
@Service
public class UserService implements IUserService {

     public static final Logger LOGGER = Logger.getLogger(UserService.class);

    @Autowired
    private IUserDAO userDAO;

    @Override
    public ResponseModel registerBorrower(User user) {
        LOGGER.debug("UserService :: registerBorrower");
        if (user.getUserName() == null || user.getUserName().isEmpty()) {
             LOGGER.error("UserService :: registerBorrower :: Name cannot be Empty");
            throw new UserInputInvalidException("Name cannot be empty");
        }else if (user.getUserEmail() == null || user.getUserEmail().isEmpty()
                || user.getUserEmail().matches("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\\\.[A-Z]{2,6}$")) {
             LOGGER.error("UserService :: registerBorrower :: Email is not valid");
            throw new UserInputInvalidException("Email cannot be empty or Email is invalid");
        }else if (user.getUserPassword().length() < ApplicationConstant.MIN_PASSWORD_LENGTH
                || user.getUserPassword().length() > ApplicationConstant.MAX_PASSWORD_LENGTH || user.getUserPassword() == null
                || user.getUserPassword().isEmpty()) {
             LOGGER.error("UserService :: registerBorrower :: Password is not valid");
            throw new UserInputInvalidException("Password length must be atleast 8");
        } else if (userDAO.userExists(user)) {
             LOGGER.error("UserService :: registerBorrower :: User already exits");
            throw new UserExistsException("User already exists");
        } else {
            
            BCryptPasswordEncoder bcrypt = new BCryptPasswordEncoder();
            user.setUserPassword(bcrypt.encode(user.getUserPassword()));
            user.setUserAIStatus(ApplicationConstant.ACTIVE);
            user.setUserRole("ROLE_BORROWER");
            user.setCreationDate(LocalDateTime.now());
            user.setModificationDate(LocalDateTime.now());

            userDAO.registerBorrower(user);
            
            ResponseModel response = new ResponseModel();
            response.setMessage("User registered successfully");
            response.setStatus(HttpStatus.CREATED.value());
            response.setTimestamp(LocalDateTime.now());
            return response;

        }
    }

}