package com.casestudy.rms.service;

import java.util.List;

import com.casestudy.rms.dto.PolicyResponse;
import com.casestudy.rms.dto.ResponseModel;
import com.casestudy.rms.model.FinancialAnalyst;
import com.casestudy.rms.model.Lender;

/** Declares set of services for Lender. */
public interface ILenderService {

    /** Register a Lender.
     * 
     * @param lender
     *            - Lender
      */
    ResponseModel registerLender(Lender lender);

    /** Add Financial Analyst to Lender.
     * 
     * @param financialAnalyst
     *            - Financial Analyst
     * @param lender
     *            - Lender
      */
    ResponseModel addFinancialAnalyst(FinancialAnalyst financialAnalyst, Lender lender);

    /** Gets Lender corresponding to Lender ID.
     * 
     * @param lenderId
     *            - Lender ID
     * @return Lender */
    Lender getLender(int lenderId);

    /** Add Policy.
     * 
     * @param policyResponse
     *            - Policy
     * @param lender
     *            - Lender
     */
    ResponseModel addPolicy(PolicyResponse policyResponse, Lender lender);

    /** Update Policy.
     * 
     * @param policyResponses
     *            - Policy
     * @param lender
     *            - Lender
     * @return boolean */
    ResponseModel updatePolicyDetail(PolicyResponse[] policyResponses, Lender lender);

    /** View Policy.
     * 
     * @param lenderId
     *            - Lender ID
     * @return List of Policy */
    List<PolicyResponse> viewPolicy(int lenderId);
    
    /**
     * View Financial Analyst corresponding to lender.
     * @param lenderId - Lender Id
     * @return List of Financial Analyst
     */
    List<FinancialAnalyst> viewFinancialAnalyst(int lenderId);

}