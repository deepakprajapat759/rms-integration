package com.casestudy.rms.service;

import org.springframework.stereotype.Service;

@Service
public class TestServiceImpl implements ITestService {

	
	@Override
	public String m1() {
		// TODO Auto-generated method stub
		return "BORROWER";
	}

	@Override
	public String m2() {
		// TODO Auto-generated method stub
		return "LENDER";
	}

	@Override
	public String m3() {
		// TODO Auto-generated method stub
		return "ADMIN";
	}

	@Override
	public String m4() {
		// TODO Auto-generated method stub
		return "FA";
	}

}
