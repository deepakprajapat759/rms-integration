package com.casestudy.rms.service;

import com.casestudy.rms.dto.ResponseModel;
import com.casestudy.rms.model.User;

/** Declare a set of services for User. */
public interface IUserService {

    /** Register a Borrower.
     * 
     * @param user
     *            - User
*/
    ResponseModel registerBorrower(User user);
}