package com.casestudy.rms.service;

import java.util.List;

import com.casestudy.rms.dto.FinancialAnalystReceivedCreditAppDTO;

/**
 * Declares set of services for FinancialAnalystService.
 *
 */
public interface IFinancialAnalystService {
    	/** Fetch Credit Application
    	 * 
    	 * @param faid - financial analyst ID.
    	 * @return - List of Credit application corresponding to FA.
    	 */
    	List<FinancialAnalystReceivedCreditAppDTO>fetchCreditApp(int faid);
    	
}
