import { Injectable } from '@angular/core';

import { HttpClient,HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';


export class User{
  constructor(
    public userId:string,
    public userEmail:string,
    public userRole:string,
    public userName:string,
    public userAIStatus:string
     ) {}
  
}


@Injectable()
export class AuthenticationService {

  constructor(private httpClient:HttpClient) { }

  authenticate(username, password) {
    /* if (username === "admin@rms.com" && password === "admin123") {
      sessionStorage.setItem('username', username)
      console.log("User Authenticated");
      return true;
    } else {
      return false;
    }
  */ 
console.log(username)
console.log(password)
 const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(username + ':' + password) });
console.log(username)

 return this.httpClient.get<User>('http://localhost:8080/rms/login/validateLogin?emailId='+username+'',{headers}).pipe(
  map( 
    userData => {
      console.log(" --after ")
      console.log(userData)
     sessionStorage.setItem('username',username);
     return userData;
    },   (response) => response.json()
    

  )


 );
  }

  authenticateLender(username, password) {
    if (username === "lender@rms.com" && password === "lender123") {
      sessionStorage.setItem('username', username)
      console.log("User Authenticated");
      return true;
    } else {
      return false;
    }
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('username')
    console.log(user)
    console.log("InsideUserLoggedIn")
    console.log(!(user === null))
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('username')
  }
}