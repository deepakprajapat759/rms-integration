import { Component, OnInit } from '@angular/core';
import {AuthenticationService, User} from './authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent implements OnInit {

  invalidCredentials = true
  username = ''
  password = ''
  invalidLogin = false

  constructor(private router : Router,private loginservice: AuthenticationService) { 

  }

  ngOnInit() {
  }
 checkLogin() {
  (this.loginservice.authenticate(this.username, this.password).subscribe(
    data => {
      console.log("-S-S-")
      console.log(data)
      if(data.userRole === 'ROLE_BORROWER'){
        this.router.navigate(['borrower-home'])
        console.log("Navigate to borrower Home")     
      }else if (data.userRole === 'ROLE_LENDER'){
        this.router.navigate(['lender-home'])
        console.log("Navigate to lender Home") 
      }
      else if  (data.userRole === 'ROLE_FINANCIAL_ANALYST'){
        this.router.navigate(['financial-analyst-home'])
        console.log("Navigate to financial Home") 
      }
      else if (data.userRole === 'ROLE_ADMIN'){
        this.router.navigate(['admin-home'])
        console.log("Navigate to Admin Home") 
      }else {
        console.log("Invalid credentials .. ")
      }
      this.invalidLogin = false
      console.log("Invalid Login --")
      console.log(this.invalidLogin)
    },
    error => {
      this.invalidLogin = true
     if(error.status === 401) alert('Invalid');
      
    }
    
  )
  );
  
  }
  


  loginUser(e) {
    e.preventDefault();
  	console.log(e);
  	 this.username = e.target.elements[0].value;
  	 this.password = e.target.elements[1].value;
    this.checkLogin();
    console.log("Logging Process done")
    if(this.invalidCredentials){ 
      console.log("Invalid Credentials")
    }else {
      console.log("Loggin Success")
    } 
    //console.log(statusCodes)
    /*
  	e.preventDefault();
  	console.log(e);
  	 this.username = e.target.elements[0].value;
  	 this.password = e.target.elements[1].value;
  	console.log(this.username, this.password)
    */
    
    /*
     if (this.loginservice.authenticate(this.username, this.password)
    ) {  
      this.invalidLogin = false
      this.router.navigate(['admin-home'])
    
    }else if (this.loginservice.authenticateLender(this.username, this.password)){
      this.invalidLogin = false
      this.router.navigate(['lender-home'])
    }
     else
      this.invalidLogin = true
    */

/*
  	if(username == 'admin' && password == 'admin') {
     // this.user.setUserLoggedIn();
  	//	this.router.navigate(['dashboard']);
  	}


      let headers = new Headers();
    headers.append('Accept', 'application/json')
    // creating base64 encoded String from user name and password
    var base64Credential: string = btoa( username+ ':' + password);
    //localStorage.setItem("hederdata",base64Credential)
    headers.append("Authorization", "Basic " + base64Credential);
    let options = new RequestOptions();
    options.headers=headers;

   
    return this.http.get(this._url,options).pipe(map((response: Response) => {
      // login successful if there's a jwt token in the response
      let user = response.json();// the returned user object is a principal object
      if (user) {
// store user details  in local storage to keep user logged in between page refreshes
        localStorage.setItem('currentUser', JSON.stringify(user));
        console.log(user)
      }
    }));
    */ 
  }


}