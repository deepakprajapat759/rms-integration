import { Lender } from './lender';

describe('Lender', () => {
  it('should create an instance', () => {
    expect(new Lender()).toBeTruthy();
  });
});
