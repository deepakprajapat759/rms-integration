import { Injectable } from '@angular/core';

import { HttpClient,HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';


export class User{
  constructor(
    public userId:string,
    public userEmail:string,
    public userRole:string,
    public userName:string,
    public userAIStatus:string
     ) {}
}


/**
 *  For passing data from one componenet to other component 
 * 
 * 1. import { BehaviorSubject } from 'rxjs';
 *  
 * Inside Sevice 
 * 2.   private user = new BehaviorSubject<User>(null);
        currentUser = this.user.asObservable();

 * 3. Inside Service , Inside get Http 
          this.updateCurrentUser(userData);


          wherever you want to use it, Inside the constructor.

          

           constructor(
              private authService: AuthenticationService) {

                authService.currentUser.subscribe(user => {
                  console.log('user,..', user);
                  
                })
               }
  
 */

@Injectable()
export class AuthenticationService {

  private user = new BehaviorSubject<User>(null);
  currentUser = this.user.asObservable();

  constructor(private httpClient:HttpClient) { }

  authenticate(username, password) {
 
  const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(username + ':' + password) });
  console.log(username)

 return this.httpClient.get<User>('http://localhost:8080/rms/login/validateLogin?emailId='+username+'',{headers}).pipe(
  map( 
    userData => {
      console.log(" --after ")
      console.log(userData)
      this.updateCurrentUser(userData);

   //  sessionStorage.setItem('username',username);
   //  sessionStorage.setItem('auth', JSON.stringify({ Authorization: 'Basic ' + btoa(username + ':' + password) }));
     localStorage.setItem('username',username);
     localStorage.setItem('auth', JSON.stringify({ Authorization: 'Basic ' + btoa(username + ':' + password) }));
     localStorage.setItem('currentUser', JSON.stringify(userData));
     return userData;
    },   (response) => response.json()
   )
 );
  }

  updateCurrentUser(user){
    this.user.next(user);
    console.log('Value of currebt user updated', user);
    
  }


  isUserLoggedIn() {
//    let user = sessionStorage.getItem('username')
    let user = localStorage.getItem('username')

    console.log(user)
    console.log("InsideUserLoggedIn")
    console.log(!(user === null))
    return !(user === null)
  }

  logOut() {
    //sessionStorage.removeItem('username')
    //sessionStorage.removeItem('username')
    localStorage.removeItem('username')
    localStorage.removeItem('auth')
    localStorage.clear();
  
  }
}