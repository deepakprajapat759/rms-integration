import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FAReceivedCreditApp } from '../model/fareceived-credit-app';
import { map } from 'rxjs/operators';
import  Links from './../links.module';
import { AuthenticationService } from 'src/app/login-form/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class FinancialAnalystService {
  currentUserID : string 
  constructor(private httpClient : HttpClient, private authService: AuthenticationService) { 
   }

  getHoldCreditApp()
  {
   //const authJSON =  sessionStorage.getItem('auth');
   const authJSON =  localStorage.getItem('auth');
   console.log(authJSON);
  if(authJSON && authJSON !== ''){
      
      const headers = new HttpHeaders(JSON.parse(authJSON));
     /* 
      this.authService.currentUser.subscribe(user => {
      console.log('user,.. Id' , user.userId);
      this.currentUserID = user.userId;
       //  this.currentUserID = user.userId;
       //console.log('current user .. ID ',this.currentUserID); 
     })
    */
    var currentUser = JSON.parse(localStorage.getItem('currentUser'));
    this.currentUserID=currentUser.userId;


      return this.httpClient.get<FAReceivedCreditApp []>(Links.FA_Credit_HOLD+ this.currentUserID ,{headers}).pipe(
  map( 
    userData => {
      console.log(" --Inside FA ")
      console.log(userData)
    
     return userData;
    },   (response) => response.json()
   )
 );
  }

   }


   /*
    return this.http.get<FAReceivedCreditApp []>('http://localhost:8080/rms/financial-analyst/view-credit-app-form?faid=7101');
  }
  */
}
