export class Borrower {
    userName: string;
    userEmail: string;
    userPassword:string;
}
