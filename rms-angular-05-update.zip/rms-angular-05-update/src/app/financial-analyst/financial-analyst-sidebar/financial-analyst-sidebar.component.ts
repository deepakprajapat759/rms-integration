import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-financial-analyst-sidebar',
  templateUrl: './financial-analyst-sidebar.component.html',
  styleUrls: ['./financial-analyst-sidebar.component.css']
})
export class FinancialAnalystSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  
}
