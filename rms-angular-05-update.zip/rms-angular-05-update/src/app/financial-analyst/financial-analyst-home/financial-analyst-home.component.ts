import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/login-form/authentication.service';

@Component({
  selector: 'app-financial-analyst-home',
  templateUrl: './financial-analyst-home.component.html',
  styleUrls: ['./financial-analyst-home.component.css']
})
export class FinancialAnalystHomeComponent implements OnInit {
  currentUserName : string;
  currentUserEmail : string ;
  constructor(private authService : AuthenticationService) {
    /*
    authService.currentUser.subscribe(user => {
      console.log('user,..', user);
      this.currentUserName = user.userName;
      this.currentUserEmail= user.userEmail;
      
    }) 
  */
 var currentUser = JSON.parse(localStorage.getItem('currentUser'));
 console.log('Inside View Recied Compnent Ts',currentUser);
 this.currentUserName = currentUser.userName;
 this.currentUserEmail = currentUser.userEmail; 
    

  }

  ngOnInit() {
  }

}
