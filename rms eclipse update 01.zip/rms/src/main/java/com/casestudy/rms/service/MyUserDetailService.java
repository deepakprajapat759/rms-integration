package com.casestudy.rms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.casestudy.rms.dao.IUserDAO;
import com.casestudy.rms.model.User;
import com.casestudy.rms.principal.UserPrincipal;

/**
 * 
 * @author neeraj.vyas
 *
 */
@Service
public class MyUserDetailService implements UserDetailsService {
	
	@Autowired
	private IUserDAO userDAO;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		//get the username from DAO.
		User user = userDAO.getUserByEmail(username);
		
		if(user == null) {
			System.out.println("--------------XXXXXXXX----------------------------");
			throw new UsernameNotFoundException(" User 404 - not found");
		}
		
		return new UserPrincipal(user);
	}

}
