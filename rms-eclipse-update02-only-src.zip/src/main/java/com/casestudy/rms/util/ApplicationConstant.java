package com.casestudy.rms.util;

/** Contains Application Constants.
 * 
 * @author impetus */
public final class ApplicationConstant {

    public static final int  NOT_APPROVED = 0;
    public static final int  ACTIVE = 1;
    public static final int  INACTIVE = 2;
    
    /**
     * Private Constructor.
     */
    private ApplicationConstant() {
        
    }
    

}
