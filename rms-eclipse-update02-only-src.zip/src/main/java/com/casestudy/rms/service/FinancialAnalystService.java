package com.casestudy.rms.service;

/**
 * Provides Services to Financial Analyst.
 * @author impetus
 *
 */
public class FinancialAnalystService implements IFinancialAnalystService {

}
