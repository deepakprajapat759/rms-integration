import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lender-home',
  templateUrl: './lender-home.component.html',
  styleUrls: ['./lender-home.component.css']
})
export class LenderHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
