import { FAReceivedCreditApp } from './fareceived-credit-app';

describe('FAReceivedCreditApp', () => {
  it('should create an instance', () => {
    expect(new FAReceivedCreditApp()).toBeTruthy();
  });
});
