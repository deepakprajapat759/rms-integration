import { NgModule } from "@angular/core";
import { CommonModule } from '@angular/common';
import {ViewDetailsDialougComponent} from './view-details-dialoug.component';

import {MatDialogModule} from '@angular/material/dialog';


@NgModule( {

    declarations : [ViewDetailsDialougComponent],
    imports : [MatDialogModule] ,
    entryComponents : [ViewDetailsDialougComponent],
    exports : [ViewDetailsDialougComponent]
}
)
export class ViewDetailsDialougModule{}