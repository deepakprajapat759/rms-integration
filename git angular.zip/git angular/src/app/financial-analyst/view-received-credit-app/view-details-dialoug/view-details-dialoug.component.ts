import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-view-details-dialoug',
  templateUrl: './view-details-dialoug.component.html',
  styleUrls: ['./view-details-dialoug.component.css']
})
export class ViewDetailsDialougComponent {

  constructor (public dialogRef: MatDialogRef<ViewDetailsDialougComponent> ){


  }

  close(){
    // event.preventDefault();
   // event.stopPropagation();
   this.dialogRef.close('closed');
  }

}
